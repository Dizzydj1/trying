Naming Conventions:
-------------------

  xCyS: where x is the # of output channels (1, 2 or 3),
        where y is the # of cells in series (1 or 2 currently supported)


Following are the pre-configured .HEX files located here:
---------------------------------------------------------

NarsilMQ8.HEX - BLF Q8 standard configuration for 2C1S

NarsilMGT.HEX - BLF GT buck driver special configuration

NarsilM2C2S.HEX - 2 output channels, 2S cells

NarsilM3C1S.HEX - 3 output channels, 1S cells

NarsilM3C2S.HEX - 3 output channels, 2S cells

