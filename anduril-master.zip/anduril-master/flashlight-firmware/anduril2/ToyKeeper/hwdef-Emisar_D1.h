#ifndef HWDEF_EMISAR_D1_H
#define HWDEF_EMISAR_D1_H

/* Emisar D1 driver layout
 */
// D1 driver is exactly the same as a D4
#include "hwdef-Emisar_D4.h"

#endif
