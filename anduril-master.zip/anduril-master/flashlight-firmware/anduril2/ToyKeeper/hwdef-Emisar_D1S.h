#ifndef HWDEF_EMISAR_D1S_H
#define HWDEF_EMISAR_D1S_H

/* Emisar D1S driver layout
 */
// D1S driver is exactly the same as a D4
#include "hwdef-Emisar_D4.h"

#endif
