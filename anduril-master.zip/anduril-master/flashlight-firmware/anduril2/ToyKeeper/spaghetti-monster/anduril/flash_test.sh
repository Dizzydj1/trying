#!/bin/sh

avrdude -p t1634 -c usbasp -n
